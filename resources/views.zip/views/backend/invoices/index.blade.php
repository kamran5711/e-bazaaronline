@extends('backend.layouts.master')

@section('main-content')
 <!-- DataTales Example -->
 <div class="card shadow mb-4">
     <div class="row">
         <div class="col-md-12">
            @include('backend.layouts.notification')
         </div>
     </div>
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary float-left">Invoices</h6>
      {{-- <a href="{{route('taxs.create')}}" class="btn btn-primary btn-sm float-right" data-toggle="tooltip" data-placement="bottom" title="Add User"><i class="fas fa-plus"></i> Add Tax</a> --}}
    </div>
    <div class="card-body">
      <div class="table-responsive">
        @if(count($inoices)>0)
        <table class="table table-bordered" id="banner-dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Invoice ID</th>
              <th>Agent Name</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Date</th>
              <th>Amount</th>
              <th>Payment Mode</th>
              <th>Approve</th>
            </tr>
          </thead>
          <tbody>
            @foreach($inoices as $inoice)
            @php
                $verfied=App\userVerify::where('user_id',$inoice->id)->first();
            @endphp
            <tr>
                <td ><a href="{{url('invoice/agent/'.$inoice->id)}}"># {{$inoice->invoice_id}}</a>
                    <a href="{{! is_null($inoice->user) ? url('invoices/agent/'.$inoice->user->id).'?status='.$status :'Not Found'}}"></td>
                <td>{{! is_null($inoice->user) ? $inoice->user->person_name :'Not Found'}}</td>
                <td>{{! is_null($inoice->user) ? $inoice->user->person_tel :'Not Found'}}</td>
                <td>{{! is_null($inoice->user) ?$inoice->user->email :'Record Not Found'}}</td>
                <td>{{date('d/m/Y', strtotime($inoice->created_at))}}</td>
                <td>{{! is_null($verfied) ? $verfied->membership_charge:''}} </td>
                <td>
                    @if($inoice->attachment)
                        <a style="margin-left:10px;color:#526484" target="_blank"  href="{{ url('images/'.$inoice->attachment)}}">
                            View Attachment</a>
                    @elseif($inoice->name)
                        Cash<br>{{! is_null($inoice) ? $inoice->name :'Not Found'}}<br>{{! is_null($inoice) ? $inoice->phone :'Not Found'}} / {{! is_null($inoice) ? $inoice->date :'Not Found'}}
                    @else

                    @endif
                </td>
                <td>
                  <a href="{{url('invoice/agent/'.$inoice->id)}}" class="btn  btn-sm btn-warning"><em class="icon ni ni-eye"> </em>View</a>
                  @if($inoice->attachment && $inoice->status==0 || $inoice->name && $inoice->status==0)
                    <a   href="{{url('accept/attachment/'.$inoice->id)}}" class="btn  btn-sm btn-success" onclick="return confirm('Are you sure?')"><em class="icon ni ni-repeat"></em> Accept </a>
                  @endif
                </td>
            </tr>
        @endforeach
          </tbody>
        </table>
        {{-- <span style="float:right">{{$inoices->links()}}</span> --}}
        @else
          <h6 class="text-center">No Tax found!!! Please create Tax</h6>
        @endif
      </div>
    </div>
</div>
@endsection

