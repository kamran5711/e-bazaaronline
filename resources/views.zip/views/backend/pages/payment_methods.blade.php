@extends('backend.layouts.master')
@section('main-content')
<div class="row">
    <div class="col-md-12">
       @include('backend.layouts.notification')
    </div>
</div>
<div class="card shadow m-3">
    <h5 class="card-header">Payment Methods</h5>
    <div class="card-body">
      <form method="post" action="{{route('admin.save_payment_methods')}}" enctype="multipart/form-data">
        {{csrf_field()}}
        <div class="row ml-1">
            <div class="col-col-6">
                <div class="form-group">
                    <label for="">Title</label>
                    <input type="text" class="form-control" placeholder="Title" name="title" value="{{old('title')}}{{isset($record->title) ? $record->title : ""}}">
                    @error('title')
                    <span class="text-danger">{{$message}}</span>
                    @enderror
                </div>
            </div>
        </div>
        {{-- <br /> --}}
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <textarea name="content" id="save_payment_methods">
                        {!!isset($record->content) ? $record->content :  ""!!} {{old('content')}}
                    </textarea>
                    @error('content')
                    <span class="text-danger">{{$message}}</span><br>
                    @enderror
                    <button class="btn btn-success mt-3" type="submit">Save</button>
                </div>
            </div> 
        </div>
      </form>
    </div>
</div>
@endsection
@push('styles')
<link rel="stylesheet" href="{{asset('backend/summernote/summernote.min.css')}}">
@endpush
@push('scripts')
<script src="{{asset('backend/summernote/summernote.min.js')}}"></script>

<script>

    // $('#lfm').filemanager('image');
    $(document).ready(function() {
      $('#save_payment_methods').summernote({
        placeholder: "Write short description.....",
          tabsize: 2,
          height: 300
      });
    });
    </script>
@endpush


