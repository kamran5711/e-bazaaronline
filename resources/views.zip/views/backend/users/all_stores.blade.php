@extends('backend.layouts.master')

@section('main-content')
 <!-- DataTales Example -->
 <div class="card shadow m-3">
     <div class="row">
         <div class="col-md-12">
            @include('backend.layouts.notification')
         </div>
     </div>
    <div class="card-header py-3 bg-primary text-white">
      <h6 class="m-0 font-weight-bold float-left">All Stores/Bussinesses</h6>
      {{-- <a href="{{route('users.create')}}" class="btn btn-primary btn-sm float-right" data-toggle="tooltip" data-placement="bottom" title="Add Customer"><i class="fas fa-plus"></i> Add Customer</a> --}}
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered table-sm table-hover">
          <thead>
            <tr>
              <th>#</th>
              <th>Name </th>
              <th>Email</th>
              <th>Phone#</th>
              <th>Type</th>
              <th>Status</th>
              <th width="100">Action</th>
            </tr>
          </thead>
          <tbody>
            @php
            $counter = 1;
            @endphp
            @foreach($stores as $store)
            @php
                $modules = json_decode($store->modules, true);
                // dd($modules);
            @endphp
                <tr> 
                  <td >{{ $counter++ }}</td>
                  <td>{{$store->name}}</td>
                  <td>{{$store->email}}</td>
                  <td>{{$store->phone}}</td>
                  <td>{{$store->type->name}}</td>
                  <td>
                    @switch($store->status)
                        @case(1)
                          <span class="text-success">Active</span>
                            @break
                        @case(2)
                          <span class="text-danger">In-active</span>
                            @break
                        @default
                          <span class="text-warning">Pending</span>
                    @endswitch
 
                  </td>
                  <td class="text-center">

                    <div class="dropdown">
                      <button class="btn btn-primary btn-sm dropdown-toggle" type="button" data-toggle="dropdown">Open
                      <span class="caret"></span></button>
                      <ul class="dropdown-menu">
                        <li class="text-success dropdown-item">
                            <a data-toggle="modal" data-target="#myModal{{$store->id}}" >approve</a>
                        </li>
                        <li class="text-info dropdown-item">
                            <a href="{{url('superadmin/users/'.$store->id)}}" class="text-info">view</a></li>
                        <li>
                        <li class="text-primary dropdown-item">
                            <a href="{{route('user.payments',$store->id)}}" class="text-primary">payment</a>
                        </li>
                      </ul>
                    </div>
                  </td>
                </tr> 
                
                <div class="container">
                  <div class="modal fade" id="myModal{{$store->id}}" role="dialog">
                      <div class="modal-dialog">
                      @php
                          $verfied = App\UserVerify::where('store_id', $store->id)->first();
                      @endphp
                      <!-- Modal content-->
                          <div class="modal-content">
                              <div class="modal-header text-white bg-primary">
                                  <h5 class="modal-title">{{ $store->name }}</h5>
                                  <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                  </button>
                              </div>
                              <div class="modal-body">
                                  <form action="{{route('user.enable',['id'=>$store->id])}}" method="post">
                                      @csrf
                                      <input type="hidden" name="user_id" value="{{$store->id}}">
                                      <label for="recipient-name" class="col-form-label">Select Status</label>
                                      <select class="custom-select" name="is_active">
                                          <option value="1"  {{ ($store->status) == '1' ?  'selected' : null }}>Active</option>
                                          <option value="0" {{ ($store->status) == '0' ?  'selected' : null }}>Inactive</option>
                                      </select>
                                      {{-- <div class="mb-3">
                                          <label for="">Modules</label>
                                          <input type="checkbox" class="form-control">
                                      </div> --}}
                                      <div class="mb-2 mt-3">
                                        <div>Modules:</div>
                                        @foreach ($modules as $key => $value)
                                        {{ $value }}
                                        <div class="form-check form-check-inline">
                                          <input class="form-check-input" type="checkbox" id="{{ $key }}" name="{{ $key}}" value="1" @php echo ($value == 1) ? 'checked' : null @endphp />
                                          <label class="form-check-label" for="{{ $key }}">{{ $key}}</label>
                                        </div>
                                        @endforeach
                                      </div>
                                      <div class="mb-3">
                                          <label for="recipient-name" class="col-form-label">Membership charges</label>
                                          <input type="number" value="{{! is_null($verfied) ? $verfied->membership_charge :'0'}}" name="membership_charge" class="form-control" id="recipient-name" >
                                      </div>
                                      <div class="mb-3">
                                          <label for="recipient-name" class="col-form-label">Setup charges</label>
                                          <input type="number"  value="{{! is_null($verfied) ? $verfied->setup_charge :'0'}}" name="setup_charge" class="form-control" id="recipient-name">
                                      </div>
                                      <div class="mb-3">
                                          <label for="recipient-name" class="col-form-label">Software charges</label>
                                          <input type="number"  value="{{! is_null($verfied) ? $verfied->software_charge :'0'}}" name="software_charge" class="form-control" id="recipient-name">
                                      </div>
                                      <div class="mb-3">
                                          <label for="recipient-name" class="col-form-label">Verify Date</label>
                                          <input type="date" value="{{! is_null($verfied) ? $verfied->verified_date :''}}" required name="verified_date" class="form-control" id="recipient-name" >
                                      </div>
                                      <div class="mb-3 text-right">
                                          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                          <button type="submit" class="btn btn-primary">Update</button>
                                      </div>
                                  </form>
                              </div>
                          </div>

                      </div>
                  </div>

              </div>
            @endforeach
          </tbody>
        </table>
        <span style="float:right">{{$stores->links()}}</span>
      </div>
    </div>
</div>
@endsection

@push('styles')
  <link href="{{asset('backend/vendor/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" />
@endpush

@push('scripts')

  <!-- Page level plugins -->
  <script src="{{asset('backend/vendor/datatables/jquery.dataTables.min.js')}}"></script>
  <script src="{{asset('backend/vendor/datatables/dataTables.bootstrap4.min.js')}}"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
@endpush