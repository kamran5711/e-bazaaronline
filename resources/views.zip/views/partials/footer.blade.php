<footer class="main-block dark-bg">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="copyright">
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    <ul>
                        <li><a class="nav-link" href="{{ url('about-us') }}">ABOUT US</a></li>
                        <li><a class="nav-link" href="{{ url('privacy-policy') }}">PRIVACY POLICY</a></li>
                        <li><a class="nav-link" href="{{ url('terms-and-conditions')}}">TERMS & CONDITIONS</a></li>
                         <li><a class="nav-link" href="{{ url('faqs')}}">FAQs</a></li>
                    </ul> 
                    <p>Copyright ©  Ebazaar {{date('Y')}} - All rights Reserved |  <a   target="_blank" style="text-decoration: none;"  href="https://softechbusinessservices.com/" target="_blank">Softech Business Services</a></p>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. 
                     <ul>
                        <li><a href="#"><span class="ti-facebook"></span></a></li>
                         <li><a href="#"><span class="ti-twitter-alt"></span></a></li>
                         <li><a href="#"><span class="ti-instagram"></span></a></li>-->
                     </ul>
                </div>
            </div>
        </div>
    </div>
</footer>