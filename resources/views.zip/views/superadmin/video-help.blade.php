@extends('layouts.subscribelogin')

@section('content')



    <video width="1000" height="600" controls>
        <source src="{{asset('images/E bazaar (2).mp4')}}" type="video/mp4">
        Your browser does not support the video tag.
    </video>

@endsection