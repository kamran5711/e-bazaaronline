@extends('layouts.admin')

@section('content')
    <style>

      li{
          padding: 20px;
      }
      li a{
          color: black;
      }
      th{
          background: #212529;
          color: white;
      }
    </style>
    <div class="nk-content-wrap">

        @if(Session::has('success'))

            <p class="alert alert-success">{{ session('success')}}</p>

        @endif

        <div class="nk-block">

            <div class="card card-bordered card-full">
                <div class="card-inner">
                    <div class="card-title-group">
                        <div class="container-fluid">
                            <h2 class="text-center">Invoices</h2>

                            <ul class="nav nav-tabs">
                                <li class="active"><a data-toggle="tab" href="#home">Unpaid</a></li>
                                <li><a data-toggle="tab" href="#menu1">Paid</a></li>
                                <li><a data-toggle="tab" href="#menu2">All</a></li>
                            </ul>

                            <div class="tab-content">
                                <div id="home" class="tab-pane active">
                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th scope="col">Invoice ID</th>
                                            <th scope="col">Agent Name</th>
                                            <th scope="col">Phone</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Payment Mode</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Approve</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($inoices as $inoice)
                                            @if($inoice->status==0)
                                                <tr>
                                                    <td><a href="{{url('invoice/agent/'.$inoice->id)}}"># {{$inoice->invoice_id}}</a></td>
                                                     
                                                    <td>{{! is_null($inoice->user) ? $inoice->user->person_name :'Not Found'}}</td>
                                                    <td>{{$inoice->user->person_tel}}</td>
                                                    <td>{{$inoice->user->email}}</td>
                                                    <td>{{date('d/m/Y', strtotime($inoice->created_at))}}</td>
                                                    <td>
                                                    @if($inoice->attachment)
                                                        <a style="margin-left:10px;color:#526484" target="_blank"  href="{{ url('images/'.$inoice->attachment)}}">
                                                            View Attachment
                                                        </a>
                                                        @else
                                                        Cash<br>{{! is_null($inoice) ? $inoice->name :'Not Found'}}<br>{{! is_null($inoice) ? $inoice->phone :'Not Found'}}
                                                   @endif
                                                    </td>
                                                    <td><button type="button" class="btn btn-danger">UnPaid </button></td>
                                                   <td>
									<ul class="link-list-plain">
										<li style="padding: 3px;">
											<a href="{{url('invoice/agent/'.$inoice->id)}}" class="btn btn-dim btn-sm btn-primary"><em class="icon ni ni-eye"> </em>View</a></li>
										
										@if($inoice->attachment && $inoice->status==0 || $inoice->name && $inoice->status==0)

										<li style="padding: 3px;"><a   href="{{url('accept/attachment/'.$inoice->id)}}"  onclick="return confirm('Are you sure?')"><em class="icon ni ni-repeat"></em> Accept </a></li>

										@endif
									</ul>
                                    </td>
                                                </tr>
                                            @endif
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                <div id="menu1" class="tab-pane fade">
                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th scope="col">Invoice ID</th>
                                            <th scope="col">Agent Name</th>
                                            <th scope="col">Phone</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Amount</th>
                                            <th scope="col">Payment Method</th>
                                            <th scope="col">Status</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($inoices as $inoice)
                                            @if($inoice->status==1)
                                                @php
                                                    $verfied=App\userVerify::where('user_id',$inoice->id)->first();
                                                @endphp
                                                <tr>
                                                    <td><a href="{{url('invoice/agent/'.$inoice->id)}}"># {{$inoice->invoice_id}}</a></td>
                                                    <td>{{! is_null($inoice->user) ? $inoice->user->person_name :'Not Found'}}</td>
                                                    <td>{{$inoice->user->person_tel}}</td>
                                                    <td>{{$inoice->user->email}}</td>
                                                    <td>{{date('d/m/Y', strtotime($inoice->created_at))}}</td>
                                                    @if($inoice->status==1)
                                                        <td>{{! is_null($verfied) ? $verfied->membership_charge :''}} </td>
                                                    @else<td></td>
                                                    @endif
                                                      <td>
                                                    @if($inoice->attachment)
                                                        <a style="margin-left:10px;color:#526484" target="_blank"  href="{{ url('images/'.$inoice->attachment)}}">
                                                            View Attachment
                                                        </a>
                                                        @else
                                                        Cash<br>{{! is_null($inoice) ? $inoice->name :'Not Found'}}<br>{{! is_null($inoice) ? $inoice->phone :'Not Found'}}
                                                   @endif
                                                    </td>
                                                    <td><button type="button" class="btn btn-success">Paid </button></td>
                                                </tr>
                                            @endif
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                <div id="menu2" class="tab-pane fade">
                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th scope="col">Invoice ID</th>
                                            <th scope="col">Agent Name</th>
                                            <th scope="col">Phone</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Amount</th>
                                            <th scope="col">Payment Method</th>
                                            <th scope="col">Status</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($inoices as $inoice)
                                            @php
                                                $verfied=App\userVerify::where('user_id',$inoice->id)->first();
                                            @endphp
                                                <tr>
                                                    <td><a href="{{url('invoice/agent/'.$inoice->id)}}"># {{$inoice->invoice_id}}</a></td>
                                                  <td>{{! is_null($inoice->user) ? $inoice->user->person_name :'Not Found'}}</td>
                                                    <td>{{$inoice->user->person_tel}}</td>
                                                    <td>{{$inoice->user->email}}</td>
                                                    <td>{{date('d/m/Y', strtotime($inoice->created_at))}}</td>
                                                    @if($inoice->status==1)
                                                    <td>{{! is_null($verfied) ? $verfied->membership_charge :''}} </td>
                                                    @else<td></td>
                                                    @endif
                                                      <td>
                                                    @if($inoice->attachment)
                                                        <a style="margin-left:10px;color:#526484" target="_blank"  href="{{ url('images/'.$inoice->attachment)}}">
                                                            View Attachment
                                                        </a>
                                                        @elseif($inoice->name)
                                                        Cash<br>{{! is_null($inoice) ? $inoice->name :'Not Found'}}<br>{{! is_null($inoice) ? $inoice->phone :'Not Found'}}
                                                    @else<td>e</td>
                                                   @endif
                                                    </td>
                                                            @if($inoice->status==1)
                                                        <td><button type="button" class="btn btn-success">Paid </button></td>
                                                        @elseif($inoice->status==0)
                                                        <td><button type="button" class="btn btn-danger">UnPaid </button></td>
                                                    @endif

                                                </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
