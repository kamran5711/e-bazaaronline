@extends('layouts.admin')
@section('content')

 <style>
     
      .zoom {
        transition: transform .2s; /* Animation */
      }

      .zoom:hover {
        transform: scale(3.2);
      }
  </style>

<div class="nk-content-wrap">
    @if(Session::has('message'))
    <div class="example-alert mb-4">
        <div class="alert alert-success alert-icon">
            <em class="icon ni ni-check-circle"></em>
            <strong>{{ session('message')}}</strong>
        </div>
    </div>
    @endif
    <div class="card card-bordered ">
        <div class="card-inner" style="background-color:#a19c9838">
            <!-- <div class="card-head" > -->
                <h5 class="card-title"><Details>Customer </Details> </h5>
            </div>
            <table class="table table-bordered" >
    <thead>
      <tr>
        <th>Business Person Name</th>
        <th>{{$user->person_name}}</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Person Tel. Number</td>
        <td>{{$user->person_tel}}</td>
      </tr>
      <tr>
        <td>Business Name</td>
        <td>{{$user->domain}}</td>
      </tr>
     <tr>
      @php
       $categories=DB::table('categories')->where('id',$user->category_id)->get();
       if($categories){
          $categories=$categories;
        }else{
        $categories=null;
        }
        @endphp
        <td>Business Type</td>
        <td> 
           @foreach($categories as $categorie)
         <option value="{{$categorie->id}}">{{$categorie->name}} </option>
            @endforeach
         </td>
      </tr>
      <tr>
        <td>Business Address</td>
        <td>{{$user->address}}</td>
      </tr>
      

      <tr>
        <td>Building Name/Number</td>
        <td>{{$user->building}}</td>
      </tr>
      <tr>
        <td>Address Line 1</td>
        <td>{{$user->address1}}</td>
      </tr>
      <tr>
        <td>Address Line 2</td>
        <td>{{$user->address2}}</td>
      </tr>
      <tr>
        <td>Area</td>
        <td>{{$user->area}}</td>
      </tr>
      <tr>
        <td>City</td>
        <td>{{$user->city}}</td>
      </tr>
      <tr>
        <td>Business Address</td>
        <td>{{$user->address}}</td>
      </tr>
      <tr>
        <td>Postcode</td>
        <td>{{$user->postcode}}</td>
      </tr>
      <tr>
        <td>Business Contact Number</td>
        <td>{{$user->business_contact_number}}</td>
      </tr>
      <tr>
        <td>Business Email Address</td>
        <td>{{$user->email}}</td>
      </tr>
      <tr>
        <td>Business</td>
        <td>{{$user->your_business}}</td>
      </tr>
      @if($user->company_reg_no != "")
      <tr>
        <td>Company Registration Number</td>
        <td>{{$user->company_reg_no}}</td>
      </tr>
      @endif
      @if($user->tax_dep_nu != "")
      <tr>
        <td>Tax Department Number</td>
        <td>{{$user->tax_dep_nu}}</td>
      </tr>
      @endif
      @if($user->company_reg_cerf)
      <tr>
        <td>Company Registration Certificate</td>
        <td> <img @if($user->company_reg_cerf) class="img-fluid zoom" style="max-width:300px"  width="100" height="100"   src="{{ asset('products/images/users/'.$user->company_reg_cerf)}}"  alt="{{$user->company_reg_cerf}}" @endif></td>
      </tr>
      @endif
      @if($user->tax_dep_cerf)
      <tr>
        <td>Tax Department Certificate</td> 
        <td> <img  @if($user->tax_dep_cerf) class="img-fluid zoom" style="max-width:300px"  width="100" height="100" src="{{ asset('products/images/users/'.$user->tax_dep_cerf) }}?text=Image cap" alt="{{$user->tax_dep_cerf}}" @endif></td>
      </tr>
      @endif
      @if($user->other_reg_docu)
      <tr>
        <td>Other Registration Documents</td>
        <td> <img @if($user->other_reg_docu) class="img-fluid zoom" style="max-width:300px"  width="100" height="100" src="{{ asset('products/images/users/'.$user->other_reg_docu) }}?text=Image cap" alt="{{$user->other_reg_docu}}" @endif></td>
      </tr>
      <tr>
        @endif
        <td>Short Description</td>
        <td>{{$user->short_description}}</td>
      </tr>
      <tr>
        <td>Products description & specification</td>
        <td>{!! $user->long_description !!}</td>
      </tr>
      <tr>
        <td>Business Document</td>
        @if($user->image != "")
        <td> <img width="200" height="100" src="{{ asset('products/images/users/'.$user->image) }}?text=Image cap" alt="{{$user->image}}"></td>
        @endif
      </tr>
    </tbody>
  </table>
        <!-- </div> -->
    </div>
</div>
@endsection