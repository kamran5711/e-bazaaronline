<table>
<tr>
    <td>
        <p>Dear {{$agent_name}},</p>
        <p>Thanks for your payment .</p>
         
        <p>
        Ebazar team.
    </p>


    </td>
</tr>
</table>