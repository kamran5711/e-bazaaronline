<table>
<tr>
    <td>
        <p>Dear {{$agent_name}},</p>
        <p>Congratulation! Your OTA website is ready to make your online presence to your customers. </p>
        <p>We wish a great online business of your travel agency.</p>
        
        <p>
        Zairaa Team.
    	</p>


    </td>
</tr>
</table>