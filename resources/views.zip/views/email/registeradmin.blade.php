<table>
<tr>
    <td style="background-color: rgb(239, 242, 247); padding-bottom: 75%;">
        <p>Dear {{$agent_nam}},</p>
        <p> Recieved new Sub Domain Request registration.</p>
        <p>Name : {{$agent_name}}</p>
        <p>Phone  : {{$agent_phone}}</p>
        <p>Domain Name : {{$agent_domanin}}</p>
        <p>Address  : {{$agent_address}}</p>
        <p>Short Description : {{$short_description}}</p>

    </td>
</tr>
</table>