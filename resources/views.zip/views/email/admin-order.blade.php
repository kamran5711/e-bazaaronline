
<table>
<tr>
    <td style="background-color: rgb(239, 242, 247); padding-bottom: 75%;">
        <p>Dear {{$name}},</p>
        <p> Recieved new Order product Request </p>
        <p>Name :{{$name}}</p>
        <p>Phone :{{$phone}}</p>
        <p>Home :{{$home}}</p>
        <p>City :{{$city}}</p>
        <p>Street :{{$street}}</p>
        <p>Area :{{$area}}</p>
        <p>Delivery Date :{{$delivery_date}}</p>
    </td>
</tr>
</table>