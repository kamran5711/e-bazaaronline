@extends('frontend.layouts.master')

@section('page-title','Order Track Page')

@section('main-content')
<style>
.stepwizard-step p {
    margin-top: 0px;
    color:#666;
}
.stepwizard-row {
    display: table-row;
}
.stepwizard {
    display: table;
    width: 100%;
    position: relative;
}
.stepwizard-step button[disabled] {
    /*opacity: 1 !important;
    filter: alpha(opacity=100) !important;*/
}
.stepwizard .btn.disabled, .stepwizard .btn[disabled], .stepwizard fieldset[disabled] .btn {
    opacity:1 !important;
    color:#bbb;
}
.stepwizard-row:before {
    top: 19px;
    bottom: 0;
    position: absolute;
    content:" ";
    width: 100%;
    height: 2px;
    background-color: #ccc;
    z-index: 0;
}
.stepwizard-step {
    display: table-cell;
    text-align: center;
    position: relative;
}
.btn-circle {
    width: 40px;
    height: 40px;
    text-align: center;
    padding: 8px;
    font-size: 12px;
    line-height: 1.428571429;
    border-radius: 100%;
}
.stepwizard .fa {
    font-size: 24px;
    color:white;
}
.hidden{display:none;}
</style>
    <!-- Breadcrumbs -->
    <div class="breadcrumbs">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="bread-inner">
                        <ul class="bread-list">
                            <li><a href="{{route('home')}}?k={{request()->get('k')}}">Home<i class="ti-arrow-right"></i></a></li>
                            <li class="active"><a href="javascript:void(0);">Order Track</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <center>
    <form class="form"  action="{{route('product.track.order')}}?k={{request()->get('k')}}" method="post">
    {{ csrf_field() }}
    <!--Stepper Starts Here-->
            <div class="col-md-8">
              <br><br>
              @if (!empty($order))
              @php $status=$order->status;@endphp
              <h4 class="">{{ $order->msg }}</h4>
                <br><br>
                <div class="stepwizard ">
                  <div class="stepwizard-row setup-panel">
                      <div class="Received stepwizard-step status col-md-3 col-xs-4"> 
                          <a href="javascript:void(0)" type="button" class="btn-secondary btn-circle"><i class="fa fa-download"></i></a>
                          <p><b>Received</b></p>
                      </div>
                      <div class="Processed stepwizard-step status col-md-3 col-xs-4"> 
                          <a href="javascript:void(0)" type="button" class="btn-secondary btn-circle disabled" disabled="disabled"><i class="fa fa-refresh"></i></a>
                          <p><b>Processed</b></p>
                      </div>
                      <div class="Dispatched stepwizard-step status col-md-3 col-xs-4"> 
                          <a href="javascript:void(0)" type="button" class="btn-secondary btn-circle disabled" disabled="disabled"><i class="fa fa-tag"></i></a>
                          <p><b>Dispatched</b></p>
                      </div>
                      <div class="Delivered stepwizard-step status col-md-3 col-xs-4"> 
                          <a href="javascript:void(0)" type="button" class="btn-secondary btn-circle disabled" disabled="disabled"><i class="fa fa-check"></i></a>
                          <p><b>Delivered</b></p>
                      </div>
                  </div>
              </div>
          </div>
          <br>
          <a href="{{url("product/track")}}?k={{request()->get('k')}}" class="btn-warning btn-lg"><span class="fa fa-undo"></span> Go Back</a>
          @else
          @php $status="Undefined"; @endphp
          <br>
          <!--Stepper Ends Here-->
            <div class="col-md-9">
            <h5 style="font-size:18px;line-height: 4;" class="text-left">Enter order number <small>e.g: EC2-123001</small> to track the status of your order</h5>
                <div class="input-group">
                <input type="search" class="form-control"  name="order_number" placeholder="Enter your order number">
                <input type="hidden" name="store_id" value="{{request()->get('k')}}">
                <span class="input-group-btn">
                    <button class="btn submit_btn" type="submit" value="submit"><span class="fa fa-search" aria-hidden="true">
                    </span> Track Order</button>

                </span>
                </div>
            </div>
            @endif<br><br>
            </form>
            </center>
      
</section>
@endsection
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script>
$(document).ready(function(){
    var current_status='{{$status}}';
            var status_array=["Received", "Processed", "Dispatched", "Delivered"];
            var status_index=status_array.indexOf(current_status);
            var counter=0;
            $('.status').each(function( index ) {
              if(counter<=status_index){
                $(this).find('a').addClass('btn-success');
                $(this).find('a').removeClass('btn-secondary');
                //$(this).find('span').removeClass('text-muted');
                //$(this).find('span').addClass('text-success');
              }else{
                $(this).find('a').addClass('btn-secondary');
                //$(this).addClass('step-disabled');
                //$(this).find('button').remove();
              }
                counter++;
            });
});
</script>